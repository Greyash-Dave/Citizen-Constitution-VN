﻿# Declare characters used by this game.

define a = Character("Aarav", color="#56A3A6")
define o1 = Character("Officer 1", color="#D9534F")
define o2 = Character("Officer 2", color="#D9534F")
define r = Character("Riya Verma", color="#5EBA7D")
define ant = Character("Rajesh Thakur", color="#D98880")

# Custom Function
init python:

    def custom_sprite_transform_modal(sprite, duration=0.5, zoom=1.0, position=None, xoffset=0, yoffset=0):
        positions = {
            "left": (0.25, 0.5),
            "center": (0.5, 0.5),
            "right": (0.75, 0.5)
        }

        if position in positions:
            x, y = positions[position]
            transform = Transform(zoom=zoom, xanchor=0.5, yanchor=0.5, xpos=x, ypos=y, xoffset=xoffset, yoffset=yoffset)
        else:
            transform = Transform(zoom=zoom, xoffset=xoffset, yoffset=yoffset)

        # Show a semi-transparent black overlay
        renpy.show("black", zorder=10, at_list=[Transform(alpha=0.25)])
        
        # Show the sprite
        renpy.show(sprite, zorder=11, at_list=[transform])
        
        # Use dissolve transitions for both
        renpy.with_statement(Dissolve(duration))

    def custom_sprite_remove_modal(sprite, duration=0.5):
        # Hide the sprite and the overlay
        renpy.hide(sprite)
        renpy.hide("black")
        renpy.with_statement(Dissolve(duration))

    # Usage example:
    # $ custom_sprite_transform_modal("document_confession", duration=0.5, zoom=0.75, position="center")
    # $ custom_sprite_remove_modal("document_confession", duration=0.5)

    def custom_sprite_transform(sprite, duration=0.25, zoom=1.0, position=None, xoffset=0, yoffset=0):
        # Define default positions
        positions = {
            "left": (0.25, 0.5),
            "center": (0.5, 0.5),
            "right": (0.75, 0.5)
        }

        # Create the transform
        if position in positions:
            x, y = positions[position]
            transform = Transform(zoom=zoom, xanchor=0.5, yanchor=0.5, xpos=x, ypos=y, xoffset=xoffset, yoffset=yoffset)
        else:
            transform = Transform(zoom=zoom, xoffset=xoffset, yoffset=yoffset)

        # Show the sprite with the transform
        # renpy.show(sprite)
        # renpy.with_statement(None)
        renpy.show(sprite, at_list=[transform])
        renpy.with_statement(Dissolve(duration))

    # Usage examples:
    # custom_sprite_transform("aarav neutral", duration=0.25, zoom=1.5, position="left")
    # custom_sprite_transform("aarav neutral", duration=0.25, zoom=1.5, position="center")
    # custom_sprite_transform("aarav neutral", duration=0.25, zoom=1.5, position="right")
    # custom_sprite_transform("aarav neutral", duration=0.25, zoom=1.5, xoffset=100, yoffset=50)

    def custom_sprite_remove(sprite, duration=0.25):
        # Hide the sprite with a dissolve effect
        renpy.hide(sprite)
        renpy.with_statement(Dissolve(duration))


# The game starts here.

label start:

    play music "music/bg_music.mp3"

    # Scene 1: Aarav's Living Room
    scene bg living_room with fade

    "Aarav Mehta, an ordinary man living a simple life in the bustling city of Delhi. Little does he know, his world is about to be turned upside down."

    $ custom_sprite_transform("aarav neutral", duration=0.25, zoom=1.5, position="center", yoffset=100)
    a "These news channels, always talking about the Constitution and rights. What does it really matter in day-to-day life?"

    # Scene 2: Aarav’s Workplace
    scene bg office with fade

    "Aarav's life is ordinary. He goes to work, comes home, and spends time with his family. But today, something feels off."

    $ custom_sprite_transform("aarav confused", duration=0.25, zoom=1.5 , position="center", yoffset=100)
    a "What? Police? But why? I haven’t done anything wrong."

    # Scene 3: Police Station
    scene bg police_station with fade

    $ custom_sprite_transform("officer neutral", duration=0.25,position="right", yoffset=100)
    o1 "Aarav Mehta, you’re under suspicion for embezzlement of government funds. We have evidence linking you to the crime."

    $ custom_sprite_transform("aarav scared", duration=0.25, zoom=1.5, position="left", yoffset=100)
    a "What? There must be some mistake! I’ve done nothing wrong!"

    $ custom_sprite_transform("officer stern", duration=0.25,position="right", yoffset=100)
    o2 "We have the evidence. It’s best if you cooperate."

    # Scene 4: Introduction of the Antagonist
    scene bg police_interrogation_room with fade

    $ custom_sprite_transform("rajesh_thakur smug", duration=0.25, position="right", yoffset=100)
    ant "Aarav, my dear friend. It’s unfortunate we meet under such circumstances."

    $ custom_sprite_transform("aarav confused", duration=0.25, zoom=1.5, position="left", yoffset=100)
    a "Rajesh? What are you doing here? Are you behind this?"

    $ custom_sprite_transform("rajesh_thakur intimidating", duration=0.25, position="right", yoffset=100)
    ant "Me? I’m just trying to help you, Aarav. Sign this confession, and all this mess will go away. The officers will close the case, and you’ll be back home in no time."

    $ custom_sprite_transform("aarav scared", duration=0.25, zoom=1.5, position="left", yoffset=100)
    a "But I haven’t done anything wrong!"

    ant "Oh, I know. But the evidence… well, it says otherwise. You see, the system is tricky. But if you sign, I can make sure it’s all taken care of. Otherwise… things could get much worse."

    a "(Thinking) This feels wrong, but what choice do I have? What should I do?"

    # Decision Point
    menu:
        "Remain Ignorant and Sign the Document":
            jump bad_ending

        "Invoke His Rights and Refuse to Sign":
            jump good_ending

    # Bad Ending Path
    label bad_ending:

        a "(Fearfully) Fine… I'll sign it."

        $ custom_sprite_transform_modal("document_confession", duration=0.5, zoom=0.75, position="center")

        pause 1
        
        ant "Smart choice, Aarav. Very smart. Let's get this over with."

        $ custom_sprite_remove_modal("document_confession", duration=0.5)

        "Aarav, unaware of his rights and intimidated by Rajesh, signs the document. He is soon sentenced to jail for a crime he didn’t commit."

        scene bg jail with fade
        $ custom_sprite_transform("aarav neutral", duration=0.25, zoom=1.5, position="center", yoffset=100)

        "This is the harsh reality for those who are unaware of their fundamental rights. Knowledge is power, and ignorance can lead to ruin."

        "Bad Ending: Aarav’s lack of awareness and fear led to his downfall."

        return

    # Good Ending Path
    label good_ending:

        # hide rajesh_thakur intimidating
        $ custom_sprite_transform("aarav neutral", duration=0.25, zoom=1.5, position="left", yoffset=100)
        a "Wait… I have the right to legal representation. I won’t sign anything without a lawyer."

        $ custom_sprite_transform("rajesh_thakur smug", duration=0.25, position="right", yoffset=100)
        ant "(Sneering) A lawyer? Aarav, don’t make this harder on yourself."

        $ custom_sprite_transform("aarav confident", duration=0.25, zoom=1.5, position="left", yoffset=100)
        a "I know my rights, Rajesh. I’m not signing anything without my lawyer present."

        # $ custom_sprite_remove("rajesh_thakur intimidating")
        $ custom_sprite_remove("rajesh_thakur")
        pause 0.5
        $ custom_sprite_transform("officer neutral", duration=0.25,position="right", yoffset=100)
        o1 "(Slightly taken aback) Fine. We’ll get you your lawyer."

        # Scene 5: Lawyer’s Office
        scene bg lawyer_office with fade

        $ custom_sprite_transform("riya_verma professional", duration=0.25, zoom=1.5, position="center", yoffset=100)
        r "Aarav, you did the right thing by not signing that confession. The law is on your side, but we need to act fast."

        r "We have enough to expose Rajesh and clear your name. Let’s take this to court."

        # Scene 6: Courtroom
        scene bg courtroom with fade

        pause 1

        $ custom_sprite_transform("aarav confident", duration=0.25, zoom=1.5, position="left", yoffset=100)
        $ custom_sprite_transform("rajesh_thakur smug", duration=0.25, position="right", yoffset=100)

        pause 0.5

        $ custom_sprite_transform_modal("court_gavel", duration=0.5, zoom=0.55, position="center")

        "Aarav’s awareness and assertion of his rights led to justice being served. Rajesh Thakur’s corruption was exposed, and Aarav’s life returned to normal."

        scene bg living_room with fade

        $ custom_sprite_transform("aarav neutral", duration=0.25, zoom=1.5, position="center", yoffset=100)
        "Knowledge of your rights isn’t just important—it can be the difference between freedom and imprisonment. Aarav’s story is a reminder to all citizens: know your rights, and never be afraid to stand up for them."

        "Good Ending: Aarav’s awareness of his fundamental rights protected him and brought justice to light."

        return